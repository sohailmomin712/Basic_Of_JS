import { useContext, useEffect, useRef, useState } from "react";
import Pagination from "../Components/Pagination";
import RestaurantTable from "../Components/RestaurantTable";
import { AppContext } from "../Context/AppContext";
const getData = (page) => {
  return fetch(`https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/getrestaurants?page=${page}&limit=10`).then((res) => {
    return res.json()
  }).then((res) => res).catch((err) => {
    console.log(err.message);
  })
};
const getPageData = (page) => {
  return fetch(`https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/getrestaurants?page=${page}&limit=10`).then((res) => {
    return res.json()
  }).then((res) => res).catch((err) => {
    console.log(err.message);
  })
};

function Dashboard() {
  const { token, logoutUser, isAuth } = useContext(AppContext);
  const [data, setData] = useState({});
  const [page, setPage] = useState(1);
  const tPage = useRef(0);



  useEffect(() => {
    getData({ page }).then((res) => {
      setData(res);
      tPage.current = res.totalPages;
      console.log(tPage.current);
      // console.log(isAuth);
      // console.log(res.data);
    })
  }, []);
  // const handlePageChange = (newPage) => {
  //   // setPage(newPage)
  //   // getPageData(page).then((res) => {
  //   //   setData(res);
  //   // })
  // };



  return (
    <div>
      <h3>Dashboard</h3>
      <div>
        <button data-testid="logout-btn" onClick={logoutUser}>Logout</button>
        <p>
          Token:
          <b data-testid="user-token">{token}</b>
        </p>
      </div>
      <div style={{ display: "flex", justifyContent: "center" }}>
        {/* restaurant table */}
        <RestaurantTable data={data.data} />
      </div>
      <div data-testid="pagination-container"><Pagination currentPage={page} totalPage={tPage.current} handlePageChange={(page) => setPage(page)} /></div>
    </div>
  );
}

export default Dashboard;
